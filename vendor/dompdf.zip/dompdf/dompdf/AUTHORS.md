Dompdf was designed and developed by Benj Carson.

### Current Team

* **Brian Sweeney** (maintainer)
* **Till Berger**

### Alumni

* **Benj Carson** (creator)
* **Fabien Ménager**
* **Simon Berger**
* **Orion Richardson**

### Contributors
* **Gabriel Bull**
* **Barry vd. Heuvel**
* **Ryan H. Masten**
* **Helmut Tischer**
* [and many more...](https://github.com/dompdf/dompdf/graphs/contributors)

### Thanks

Dompdf would not have been possible without strong community support.
